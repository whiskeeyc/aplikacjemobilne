Customowa klawiatura systemowa z akcjami:

1. Wyświetlenie tekstu
2. Odtworzenie dźwięku
3. Otwarcie kamery (aparatu)
4. - tymczasowy brak
5. Wyświetlenie Toastu z napisem
6. Zmiana klawiszy na inne o innych funkcjonalnosciach
7. Sprawdzenie czy NFC jest włączone
8. Otwarcie opcji włączenia NFC
9. Otwarcie Galerii
10. Sprawdzenie, czy urządzenie jest podłączone do Internetu
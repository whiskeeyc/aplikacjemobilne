package com.example.customkeyboard;

import android.content.Intent;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.media.MediaPlayer;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.content.Context;
import android.widget.Toast;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


public class MyInputMethodService extends InputMethodService implements KeyboardView.OnKeyboardActionListener {

    @Override
    public View onCreateInputView() {
        // get the KeyboardView and add our Keyboard layout to it
        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.layout.number_pad);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }
    public View onCreateInputView2() {
        // get the KeyboardView and add our Keyboard layout to it
        KeyboardView keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        Keyboard keyboard = new Keyboard(this, R.layout.number_pad2);
        keyboardView.setKeyboard(keyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }

    public void toastMsg(String msg) {

        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        toast.show();

    }

    String isnfc = "";
    String connec = "No Internet Connection";


    @Override
    public void onKey(int primaryCode, int[] keyCodes) {

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        switch (primaryCode) {
            case 49:
                CharSequence selectedText = ic.getSelectedText(0);
                ic.commitText("THIS IS A CUSTOM KEYBOARD !", 1);
                break;
            case 50:
                MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.sample);
                mediaPlayer.start();
                break;

            case 51:
                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                startActivity(intent);
                break;
            case 52:

                break;
            case 53:
                toastMsg("Welcome to my app");
                break;
            case 54:
                setInputView(onCreateInputView2());
                break;
            case 55:
                setInputView(onCreateInputView());
                break;
            case 56:
                NfcManager manager = (NfcManager) getApplicationContext().getSystemService(Context.NFC_SERVICE);
                NfcAdapter adapter = manager.getDefaultAdapter();

                if (adapter != null && adapter.isEnabled()){
                    isnfc = "NFC is ON";
                }   else {
                    isnfc = "NFC is OFF";
                }
                toastMsg(isnfc);
                break;
            case 57:
                Intent intent2 = new Intent(Settings.ACTION_NFC_SETTINGS);
                startActivity(intent2);
                break;
            case 58:
                Intent intent3 = new Intent(Intent.ACTION_VIEW);
                intent3.setType("image/*");
                startActivity(intent3);
                break;
            case 59:
                ConnectivityManager connectivity = (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivity != null)
                {
                    NetworkInfo[] info = connectivity.getAllNetworkInfo();
                    if (info != null)
                        for (int i = 0; i < info.length; i++)
                            if (info[i].getState() == NetworkInfo.State.CONNECTED)
                            {
                                connec = "Has Internet Connection";
                            }
                }
                toastMsg(connec);
            default:

        }
    }



    @Override
    public void onPress(int primaryCode) { }

    @Override
    public void onRelease(int primaryCode) { }

    @Override
    public void onText(CharSequence text) { }

    @Override
    public void swipeLeft() { }

    @Override
    public void swipeRight() { }

    @Override
    public void swipeDown() { }

    @Override
    public void swipeUp() { }
}
package com.example.keyboard_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.FileInputStream;
import java.io.FileOutputStream;


public class KeyboardActivity extends AppCompatActivity {

    private Button btnText;
    private Button btnSound;
    private Button btnCam;
    private ToggleButton btnAdd;
    private ToggleButton btnOpen;
    private Button btnToast;
    private Button btnIsNFC;
    private Button btnNFC;
    private Button btnA1;
    private Button btnA2;
    private Button btnTextAdd;
    private Button btnClear;

    private TextView textMain;
    private EditText textAdd;

    private ConstraintLayout mainLay;
    private LinearLayout firstLay;
    private LinearLayout secondLay;


    String fileName = "C:\\Users\\whisk\\AndroidStudioProjects\\Keyboard_App\\app\\src\\main\\res\\raw\\text.txt";
    String isnfc = " ";
    String connec = "No Internet Connection";

    public void toastMsg(String msg) {

        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        toast.show();

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.keyboard);

        btnText = (Button)findViewById(R.id.btnText);
        btnSound = (Button)findViewById(R.id.btnSound);
        btnCam = (Button)findViewById(R.id.btnCam);
        btnAdd = (ToggleButton)findViewById(R.id.btnAdd);
        btnOpen = (ToggleButton)findViewById(R.id.btnOpen);
        btnToast = (Button)findViewById(R.id.btnToast);
        btnIsNFC = (Button)findViewById(R.id.btnIsNFC);
        btnNFC = (Button)findViewById(R.id.btnNFC);
        btnA1 = (Button)findViewById(R.id.btnA1);
        btnA2 = (Button)findViewById(R.id.btnA2);
        btnTextAdd = (Button)findViewById(R.id.btnTextAdd);
        textMain = (TextView)findViewById(R.id.textMain);
        textAdd = (EditText)findViewById(R.id.textAdd);
        btnClear = (Button)findViewById(R.id.btnClear);

        mainLay = (ConstraintLayout) findViewById(R.id.mainLay);
        firstLay = (LinearLayout)findViewById(R.id.firstLay);
        secondLay = (LinearLayout)findViewById(R.id.secondLay);

        NfcManager manager = (NfcManager) getApplicationContext().getSystemService(Context.NFC_SERVICE);
        NfcAdapter adapter = manager.getDefaultAdapter();

        if (adapter != null && adapter.isEnabled()){
            isnfc = "NFC is ON";
        }else {
            isnfc = "NFC is OFF";
        }



        ConnectivityManager connectivity = (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        connec = "Has Internet Connection";
                    }
            }



        final MediaPlayer mp = MediaPlayer.create(this, R.raw.sample);


        btnOpen.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    secondLay.setVisibility(View.VISIBLE);
                } else {
                    secondLay.setVisibility(View.INVISIBLE);
                }
            }
        });



        btnAdd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    textAdd.setVisibility(View.VISIBLE);
                    btnTextAdd.setVisibility(View.VISIBLE);
                } else {
                    textAdd.setVisibility(View.INVISIBLE);
                    btnTextAdd.setVisibility(View.INVISIBLE);
                }
            }
        });

        btnSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.start();
            }
        });

        btnText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textMain.setText("THIS IS A CUSTOM KEYBOARD !");
            }
        });

        btnIsNFC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textMain.setText(isnfc);
            }
        });

        btnNFC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Settings.ACTION_NFC_SETTINGS);
                startActivity(intent2);
            }
        });




        btnA2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textMain.setText(connec);
            }
        });

        btnCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
            }
        });

        btnTextAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFile(fileName, textAdd.getText().toString());
            }
        });

        btnA1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textMain.setText(readFile(fileName));
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textMain.setText(" ");
            }
        });



        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toastMsg("Welcome to my app");
            }
        });

    }
    public void saveFile(String file, String text){
        try{
            FileOutputStream fos = openFileOutput(file, Context.MODE_PRIVATE);
            fos.write(text.getBytes());
            fos.close();
            Toast.makeText(KeyboardActivity.this, "Saved", Toast.LENGTH_SHORT).show();
        }catch(Exception e) {
            e.printStackTrace();
            Toast.makeText(KeyboardActivity.this, "Error saving file", Toast.LENGTH_SHORT).show();
        }

        }


    public String readFile(String file) {
    String text = "";

        try{
            FileInputStream fis = openFileInput(file);
            int size = fis.available();
            byte[] buffer = new byte[size];
            fis.read(buffer);
            fis.close();
            text = new String(buffer);
        }catch(Exception e) {
            e.printStackTrace();
            Toast.makeText(KeyboardActivity.this, "Error saving file", Toast.LENGTH_SHORT).show();
        }

    return text;
    }
}

Aplikacja z klawiaturą (przyciskami), kazdy z nich posiada akcje:

1. Wyświetlenie tekstu
2. Odtworzenie dźwięku
3. Otwarcie kamery (aparatu)
4. Zapis do pliku dowolnego wprowadzonego tekstu
5. Wyświetlenie Toastu z napisem
6. Pojawienie się dodatkowych klawiszy
7. Sprawdzenie czy NFC jest włączone
8. Otwarcie opcji włączenia NFC
9. Odczyt ostatniej wiadomości zapisanej wcześniej do pliku z pkt. 4
10. Sprawdzenie, czy urządzenie jest podłączone do Internetu